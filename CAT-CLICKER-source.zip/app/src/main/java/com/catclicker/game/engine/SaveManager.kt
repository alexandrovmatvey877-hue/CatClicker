package com.catclicker.game.engine

import android.content.Context
import com.catclicker.game.model.*
import org.json.JSONArray
import org.json.JSONObject

class SaveManager(context: Context) {
    private val prefs = context.getSharedPreferences("cat_clicker_save", Context.MODE_PRIVATE)
    fun load(): GameState {
        val raw = prefs.getString("state", null) ?: return GameState()
        return runCatching {
            val j = JSONObject(raw)
            val cats = mutableListOf<CatInstance>()
            val a = j.optJSONArray("cats") ?: JSONArray()
            for (i in 0 until a.length()) {
                val c = a.getJSONObject(i)
                cats += CatInstance(c.getLong("uid"), c.getString("spec"), c.optDouble("energy",100.0), c.optDouble("hunger",100.0), c.optBoolean("working",true), c.optInt("phase",0), c.optInt("level",1), c.optDouble("earned",0.0))
            }
            fun strings(key: String) = buildSet { val ar=j.optJSONArray(key) ?: JSONArray(); for(i in 0 until ar.length()) add(ar.getString(i)) }
            GameState(coins=j.optDouble("coins"),fish=j.optInt("fish"),crystals=j.optInt("crystals"),stars=j.optInt("stars"),taps=j.optLong("taps"),totalCoins=j.optDouble("total"),level=j.optInt("level",1),xp=j.optDouble("xp"),ownedCats=cats,bedId=j.optString("bed","pillow"),buttonId=j.optString("button","paw"),foodStock=j.optInt("food",8),lastSavedAt=j.optLong("saved",System.currentTimeMillis()),prestige=j.optInt("prestige"),autoFeed=j.optBoolean("autoFeed"),purchasedUpgrades=strings("upgrades"),unlockedAchievements=strings("achievements"))
        }.getOrElse { GameState() }
    }
    fun save(s: GameState) {
        val j=JSONObject().put("coins",s.coins).put("fish",s.fish).put("crystals",s.crystals).put("stars",s.stars).put("taps",s.taps).put("total",s.totalCoins).put("level",s.level).put("xp",s.xp).put("bed",s.bedId).put("button",s.buttonId).put("food",s.foodStock).put("saved",System.currentTimeMillis()).put("prestige",s.prestige).put("autoFeed",s.autoFeed)
        val cats=JSONArray(); s.ownedCats.forEach { c -> cats.put(JSONObject().put("uid",c.uid).put("spec",c.specId).put("energy",c.energy).put("hunger",c.hunger).put("working",c.working).put("phase",c.phaseSeconds).put("level",c.level).put("earned",c.lifetimeCoins)) }; j.put("cats",cats)
        j.put("upgrades",JSONArray(s.purchasedUpgrades.toList())).put("achievements",JSONArray(s.unlockedAchievements.toList()))
        prefs.edit().putString("state",j.toString()).apply()
    }
}
