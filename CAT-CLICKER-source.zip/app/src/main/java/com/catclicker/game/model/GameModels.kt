package com.catclicker.game.model

data class CatSpec(
    val id: String, val name: String, val emoji: String, val price: Long,
    val multiplier: Double, val workSeconds: Int, val restSeconds: Int,
    val rarity: String, val element: String, val breed: String, val description: String
)

data class CatInstance(
    val uid: Long, val specId: String, val energy: Double = 100.0,
    val hunger: Double = 100.0, val working: Boolean = true,
    val phaseSeconds: Int = 0, val level: Int = 1, val lifetimeCoins: Double = 0.0
)

data class BedSpec(val id: String, val name: String, val price: Long, val slots: Int, val recovery: Double, val rarity: String)
data class ButtonSpec(val id: String, val name: String, val price: Long, val multiplier: Double, val catCapacity: Int, val rarity: String)
data class FoodSpec(val id: String, val name: String, val price: Long, val nutrition: Double, val icon: String)

data class GameState(
    val coins: Double = 0.0,
    val fish: Int = 0,
    val crystals: Int = 0,
    val stars: Int = 0,
    val taps: Long = 0,
    val totalCoins: Double = 0.0,
    val level: Int = 1,
    val xp: Double = 0.0,
    val ownedCats: List<CatInstance> = emptyList(),
    val bedId: String = "pillow",
    val buttonId: String = "paw",
    val foodStock: Int = 8,
    val selectedTab: Int = 0,
    val lastSavedAt: Long = System.currentTimeMillis(),
    val prestige: Int = 0,
    val autoFeed: Boolean = false,
    val purchasedUpgrades: Set<String> = emptySet(),
    val unlockedAchievements: Set<String> = emptySet()
)
