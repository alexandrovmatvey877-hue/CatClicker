package com.catclicker.game.engine

import com.catclicker.game.data.Catalogs
import com.catclicker.game.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min

class GameEngine(private val save: SaveManager) {
    private val _state = MutableStateFlow(save.load())
    val state = _state.asStateFlow()
    private var lastPersist = 0L
    private fun update(transform: (GameState)->GameState) { _state.value=transform(_state.value); persist(false) }
    private fun persist(force: Boolean) { val now=System.currentTimeMillis(); if(force || now-lastPersist>5000){save.save(_state.value);lastPersist=now} }
    init { applyOfflineProgress() }
    fun tap() = update { s ->
        val button=Catalogs.buttons.first { it.id==s.buttonId }
        val combo=if(s.ownedCats.size>=3 && s.ownedCats.mapNotNull { c->Catalogs.cats.find{it.id==c.specId}?.breed }.distinct().size==1) 1.15 else 1.0
        val crit=if((s.taps+1)%37L==0L) 3.0 else 1.0
        val amount=(1.0+s.level*0.08+if("soft_paws" in s.purchasedUpgrades) 0.5 else 0.0)*button.multiplier*combo*crit
        val xp=s.xp+1.0; val level=1+(floor(xp/100.0)).toInt()
        s.copy(coins=s.coins+amount,totalCoins=s.totalCoins+amount,taps=s.taps+1,xp=xp,level=level,unlockedAchievements=achievementSet(s.copy(taps=s.taps+1,totalCoins=s.totalCoins+amount)))
    }
    fun buyCat(id:String) = update { s ->
        val spec=Catalogs.cats.firstOrNull{it.id==id} ?: return@update s
        val cap=Catalogs.buttons.first{it.id==s.buttonId}.catCapacity
        if(s.coins<spec.price || s.ownedCats.size>=cap) return@update s
        s.copy(coins=s.coins-spec.price,ownedCats=s.ownedCats+CatInstance(System.currentTimeMillis(),id),unlockedAchievements=achievementSet(s.copy(ownedCats=s.ownedCats+CatInstance(System.currentTimeMillis(),id))))
    }
    fun buyBed(id:String)=update { s -> val b=Catalogs.beds.first{it.id==id}; if(b.price>s.coins || b.id==s.bedId) s else s.copy(coins=s.coins-b.price,bedId=id) }
    fun buyButton(id:String)=update { s -> val b=Catalogs.buttons.first{it.id==id}; if(b.price>s.coins || Catalogs.buttons.indexOf(b)>Catalogs.buttons.indexOfFirst{it.id==s.buttonId}+1) s else s.copy(coins=s.coins-b.price,buttonId=id) }
    fun buyFood(id:String,qty:Int=1)=update { s -> val f=Catalogs.foods.first{it.id==id}; val n=qty.coerceIn(1,20); if(s.coins<f.price*n) s else s.copy(coins=s.coins-f.price*n,foodStock=s.foodStock+n) }
    fun feed(uid:Long)=update { s -> if(s.foodStock<=0)s else s.copy(foodStock=s.foodStock-1,ownedCats=s.ownedCats.map{if(it.uid==uid)it.copy(hunger=100.0)else it}) }
    fun upgrade(id:String)=update { s -> val u=Catalogs.upgrades.firstOrNull{it.first==id} ?: return@update s; if(id in s.purchasedUpgrades || s.coins<u.third)return@update s; s.copy(coins=s.coins-u.third,purchasedUpgrades=s.purchasedUpgrades+id,autoFeed=s.autoFeed||id=="auto_feed") }
    fun releaseCat(uid:Long)=update { s -> s.copy(ownedCats=s.ownedCats.filterNot{it.uid==uid}) }
    fun changeTab(tab:Int)=update { it.copy(selectedTab=tab) }
    fun prestige()=update { s -> if(s.totalCoins<100000.0)s else s.copy(coins=0.0,ownedCats=emptyList(),bedId="pillow",buttonId="paw",foodStock=8,prestige=s.prestige+1,crystals=s.crystals+1,level=1,xp=0.0,totalCoins=0.0) }
    fun tick(seconds:Int=1) = update { s ->
        if(s.ownedCats.isEmpty()) return@update s
        val bed=Catalogs.beds.first{it.id==s.bedId}; var income=0.0
        var foodLeft=s.foodStock
        val restingIds=s.ownedCats.filter{!it.working}.sortedBy{it.uid}.take(bed.slots).map{it.uid}.toSet()
        val next=s.ownedCats.map { original ->
            var c=original; repeat(seconds.coerceAtMost(28800)) {
                val hungry=max(0.0,c.hunger-0.018)
                var energy=c.energy; var working=c.working; var phase=c.phaseSeconds+1
                if(working) {
                    energy=max(0.0,energy-0.11); val spec=Catalogs.cats.first{it.id==c.specId}
                    val productivity=if(hungry<20)0.15 else if(hungry<50)0.55 else 1.0
                    val rate=spec.multiplier*Catalogs.buttons.first{it.id==s.buttonId}.multiplier*0.18*productivity*(1.0+(c.level-1)*0.12)
                    if(energy>0 && hungry>0){income+=rate; c=c.copy(lifetimeCoins=c.lifetimeCoins+rate)}
                    if(phase>=spec.workSeconds || energy<=0){working=false;phase=0}
                } else {
                    val inRest= s.ownedCats.count{!it.working}
                    if(inRest<=bed.slots){energy=min(100.0,energy+bed.recovery);}
                    else energy=min(100.0,energy+bed.recovery*0.15)
                    if(phase>=Catalogs.cats.first{it.id==c.specId}.restSeconds && energy>=55){working=true;phase=0}
                }
                c=c.copy(hunger=hungry,energy=energy,working=working,phaseSeconds=phase)
                if(s.autoFeed && c.hunger<28 && foodLeft>0){c=c.copy(hunger=100.0); foodLeft--}
            }; c
        }
        s.copy(coins=s.coins+income,totalCoins=s.totalCoins+income,ownedCats=next,foodStock=foodLeft,unlockedAchievements=achievementSet(s.copy(ownedCats=next,totalCoins=s.totalCoins+income)))
    }
    private fun applyOfflineProgress(){ val s=_state.value; val elapsed=((System.currentTimeMillis()-s.lastSavedAt)/1000).toInt().coerceIn(0,8*3600); if(elapsed>0) { tick(elapsed); persist(true) } }
    private fun achievementSet(s:GameState):Set<String>{ val a=s.unlockedAchievements.toMutableSet(); if(s.taps>=100)a.add("tap100");if(s.taps>=1000)a.add("tap1000");if(s.ownedCats.size>=3)a.add("cat3");if(s.totalCoins>=10000)a.add("rich");return a }
    fun saveNow(){persist(true)}
}
