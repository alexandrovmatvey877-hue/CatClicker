package com.catclicker.game

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.catclicker.game.data.Catalogs
import com.catclicker.game.engine.GameEngine
import com.catclicker.game.engine.SaveManager
import com.catclicker.game.model.CatInstance
import com.catclicker.game.model.GameState
import kotlinx.coroutines.delay
import kotlin.math.roundToInt
import kotlin.math.absoluteValue

private val Ink=Color(0xFF352A42); private val Muted=Color(0xFF82758D); private val Pink=Color(0xFFFF8EAB); private val Purple=Color(0xFF9B83E8); private val Cream=Color(0xFFFFF8F4); private val Card=Color(0xFFFFFFFF)

class MainActivity:ComponentActivity(){ override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState); val engine=GameEngine(SaveManager(this)); setContent { CatClickerApp(engine) }}; override fun onStop(){super.onStop()} }

@Composable private fun CatClickerApp(engine:GameEngine){
    val state by engine.state.collectAsState()
    var pressed by remember { mutableStateOf(false) }; val scale by animateFloatAsState(if(pressed)0.93f else 1f,label="tap")
    LaunchedEffect(Unit){ while(true){delay(1000);engine.tick()} }
    BackHandler(state.selectedTab!=0){engine.changeTab(0)}
    MaterialTheme(colorScheme=lightColorScheme(primary=Purple,background=Cream,surface=Card,onBackground=Ink,onSurface=Ink)){
        Scaffold(containerColor=Cream,bottomBar={ NavigationBar(containerColor=Color.White) {
            val tabs=listOf("Главная" to Icons.Default.Pets,"Коты" to Icons.Default.CrueltyFree,"Магазин" to Icons.Default.Storefront,"Ферма" to Icons.Default.Agriculture,"Профиль" to Icons.Default.Person)
            tabs.forEachIndexed { i,p -> NavigationBarItem(selected=state.selectedTab==i,onClick={engine.changeTab(i)},icon={Icon(p.second,null)},label={Text(p.first,fontSize=10.sp)}) }
        }}){ pad -> Column(Modifier.fillMaxSize().padding(pad).padding(horizontal=18.dp)) {
            Header(state)
            when(state.selectedTab){
                0->HomeScreen(state,engine,scale,{pressed=true;engine.tap();pressed=false})
                1->CatsScreen(state,engine)
                2->ShopScreen(state,engine)
                3->ProductionScreen(state,engine)
                else->ProfileScreen(state,engine)
            }
        }}
    }
}

@Composable private fun Header(s:GameState){
    Row(Modifier.fillMaxWidth().padding(top=12.dp,bottom=12.dp),verticalAlignment=Alignment.CenterVertically){
        Column(Modifier.weight(1f)){Text("CAT CLICKER",fontWeight=FontWeight.Black,fontSize=19.sp,color=Ink,letterSpacing=1.sp);Text("Твоя маленькая кошачья империя",fontSize=11.sp,color=Muted)}
        CurrencyPill("🪙",fmt(s.coins)); Spacer(Modifier.width(6.dp)); CurrencyPill("🐟","${s.fish}")
    }
}
@Composable private fun CurrencyPill(icon:String,value:String){Surface(color=Color.White,shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(horizontal=10.dp,vertical=7.dp),verticalAlignment=Alignment.CenterVertically){Text(icon,fontSize=13.sp);Spacer(Modifier.width(4.dp));Text(value,fontWeight=FontWeight.Bold,fontSize=12.sp,color=Ink)}}}

@Composable private fun HomeScreen(s:GameState,e:GameEngine,scale:Float,onTap:()->Unit){
    val button=Catalogs.buttons.first{it.id==s.buttonId}; val income=s.ownedCats.sumOf{c->val spec=Catalogs.cats.first{it.id==c.specId};spec.multiplier*button.multiplier*0.18*(c.energy/100.0)*(c.hunger/100.0)}
    Column(Modifier.fillMaxSize(),horizontalAlignment=Alignment.CenterHorizontally){
        Spacer(Modifier.height(8.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column{Text("Баланс",color=Muted,fontSize=12.sp);Text("${fmt(s.coins)} монет",fontSize=25.sp,fontWeight=FontWeight.ExtraBold,color=Ink)};Surface(color=Color(0xFFFFE7EF),shape=RoundedCornerShape(15.dp)){Text("УРОВЕНЬ ${s.level}",Modifier.padding(12.dp),color=Color(0xFFB64E78),fontWeight=FontWeight.Bold,fontSize=12.sp)}}
        Spacer(Modifier.height(18.dp)); Text("Нажимай на лапку!",fontSize=16.sp,fontWeight=FontWeight.SemiBold,color=Ink)
        Box(Modifier.size(252.dp).scale(scale).clickable { onTap() },contentAlignment=Alignment.Center){
            Canvas(Modifier.fillMaxSize()) { drawCircle(Brush.linearGradient(listOf(Color(0xFFFFD4E0),Color(0xFFFF9BB7))));drawCircle(Color.White.copy(alpha=.65f),radius=size.minDimension*.43f,style=Stroke(width=5.dp.toPx()));drawCircle(Color.White.copy(alpha=.15f),radius=size.minDimension*.49f) }
            PawGraphic(Modifier.size(150.dp))
        }
        Text("КРИТИЧЕСКИЙ УДАР КАЖДЫЕ 37 НАЖАТИЙ",fontSize=9.sp,color=Muted,letterSpacing=.5.sp)
        Spacer(Modifier.height(18.dp)); Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.spacedBy(10.dp)){
            StatCard("Автодоход", "${fmt(income)}/сек", "↗",Modifier.weight(1f)); StatCard("Котики","${s.ownedCats.size}/${button.catCapacity}","♡",Modifier.weight(1f)); StatCard("Корм","${s.foodStock} порц.","+",Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp)); SectionTitle("Твоя команда", "${s.ownedCats.size} котиков")
        if(s.ownedCats.isEmpty()) EmptyHint("Пока здесь тихо. Купи первого котика в разделе «Коты».") else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(s.ownedCats.take(3),key={it.uid}){cat->CompactCat(cat)} }
        Spacer(Modifier.height(8.dp)); Surface(color=Color(0xFFEFEAFF),shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Icon(Icons.Default.AutoAwesome,null,tint=Purple);Spacer(Modifier.width(8.dp));Text("Комбо: ${if(s.ownedCats.size>=3)"три кота — +15% к кликам" else "собери 3 котов одной породы"}",fontSize=12.sp,color=Ink)}}
    }
}
@Composable private fun PawGraphic(modifier:Modifier=Modifier){Canvas(modifier){val w=size.width;val h=size.height;val c=Color.White;drawOval(c,topLeft=Offset(w*.29f,h*.46f),size=androidx.compose.ui.geometry.Size(w*.43f,h*.38f));drawCircle(c,w*.115f,Offset(w*.22f,h*.32f));drawCircle(c,w*.115f,Offset(w*.43f,h*.20f));drawCircle(c,w*.115f,Offset(w*.66f,h*.20f));drawCircle(c,w*.115f,Offset(w*.82f,h*.34f))}}
@Composable private fun StatCard(title:String,value:String,icon:String,modifier:Modifier){Surface(modifier,color=Color.White,shape=RoundedCornerShape(18.dp),shadowElevation=1.dp){Column(Modifier.padding(12.dp)){Text(icon,color=Pink,fontSize=17.sp);Text(value,fontSize=15.sp,fontWeight=FontWeight.Bold,color=Ink);Text(title,fontSize=10.sp,color=Muted)}}}
@Composable private fun SectionTitle(title:String,sub:String){Row(Modifier.fillMaxWidth().padding(vertical=9.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(title,fontWeight=FontWeight.Bold,fontSize=16.sp,color=Ink);Text(sub,fontSize=11.sp,color=Muted)}}
@Composable private fun EmptyHint(text:String){Surface(color=Color.White,shape=RoundedCornerShape(16.dp),modifier=Modifier.fillMaxWidth()){Text(text,Modifier.padding(16.dp),fontSize=12.sp,color=Muted,textAlign=TextAlign.Center)}}
@Composable private fun CompactCat(c:CatInstance){val spec=Catalogs.cats.first{it.id==c.specId};Surface(color=Color.White,shape=RoundedCornerShape(15.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(10.dp),verticalAlignment=Alignment.CenterVertically){CatAvatar(spec.emoji);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(spec.name,fontWeight=FontWeight.Bold,color=Ink);Text(if(c.working)"Работает · ${spec.element}" else "Отдыхает · ${spec.element}",fontSize=10.sp,color=Muted)};Column(horizontalAlignment=Alignment.End){Text("⚡ ${c.energy.roundToInt()}%",fontSize=11.sp,color=Ink);Text("🍗 ${c.hunger.roundToInt()}%",fontSize=11.sp,color=Ink)}}}}
@Composable private fun CatAvatar(emoji:String){
    val palette=listOf(Color(0xFFFFC58F),Color(0xFF9A8FA8),Color(0xFFFFE0A8),Color(0xFFB8A2E8),Color(0xFF8C8190))
    val fur=palette[(emoji.hashCode().absoluteValue)%palette.size]
    Canvas(Modifier.size(52.dp).background(Color(0xFFFFEDF2),CircleShape)) {
        val w=size.width; val h=size.height
        val ear=androidx.compose.ui.graphics.Path().apply{moveTo(w*.17f,h*.37f);lineTo(w*.20f,h*.08f);lineTo(w*.43f,h*.23f);close()}
        val ear2=androidx.compose.ui.graphics.Path().apply{moveTo(w*.57f,h*.23f);lineTo(w*.80f,h*.08f);lineTo(w*.83f,h*.37f);close()}
        drawPath(ear,fur);drawPath(ear2,fur);drawCircle(fur,radius=w*.36f,center=Offset(w*.5f,h*.53f))
        drawCircle(Color(0xFF493A4B),radius=w*.035f,center=Offset(w*.38f,h*.49f));drawCircle(Color(0xFF493A4B),radius=w*.035f,center=Offset(w*.62f,h*.49f))
        val nose=androidx.compose.ui.graphics.Path().apply{moveTo(w*.46f,h*.59f);lineTo(w*.54f,h*.59f);lineTo(w*.5f,h*.64f);close()};drawPath(nose,Color(0xFFDF7894))
        drawLine(Color(0xFF6E5967),Offset(w*.5f,h*.64f),Offset(w*.5f,h*.69f),strokeWidth=1.5f)
        drawLine(Color(0xFF6E5967),Offset(w*.5f,h*.68f),Offset(w*.44f,h*.72f),strokeWidth=1.3f);drawLine(Color(0xFF6E5967),Offset(w*.5f,h*.68f),Offset(w*.56f,h*.72f),strokeWidth=1.3f)
        drawLine(Color(0xFF8D7884),Offset(w*.28f,h*.62f),Offset(w*.08f,h*.58f),strokeWidth=1f);drawLine(Color(0xFF8D7884),Offset(w*.28f,h*.67f),Offset(w*.08f,h*.69f),strokeWidth=1f);drawLine(Color(0xFF8D7884),Offset(w*.72f,h*.62f),Offset(w*.92f,h*.58f),strokeWidth=1f);drawLine(Color(0xFF8D7884),Offset(w*.72f,h*.67f),Offset(w*.92f,h*.69f),strokeWidth=1f)
    }
}

@Composable private fun CatsScreen(s:GameState,e:GameEngine){
    Column(Modifier.fillMaxSize()) { SectionTitle("Коллекция котиков","${s.ownedCats.size} / ${Catalogs.buttons.first{it.id==s.buttonId}.catCapacity}")
        LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=16.dp)){items(Catalogs.cats){spec->val owned=s.ownedCats.firstOrNull{it.specId==spec.id};Surface(color=Color.White,shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(13.dp)){
            Row(verticalAlignment=Alignment.CenterVertically){CatAvatar(spec.emoji);Spacer(Modifier.width(10.dp));Column(Modifier.weight(1f)){Text(spec.name,fontWeight=FontWeight.Bold,color=Ink);Text("${spec.rarity} · ${spec.element} · ${spec.breed}",fontSize=10.sp,color=Purple)};Text("×${spec.multiplier}",fontWeight=FontWeight.Bold,color=Ink)}
            Text(spec.description,fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=7.dp,bottom=8.dp))
            if(owned==null) Button(onClick={e.buyCat(spec.id)},enabled=s.coins>=spec.price && s.ownedCats.size<Catalogs.buttons.first{it.id==s.buttonId}.catCapacity,modifier=Modifier.fillMaxWidth(),shape=RoundedCornerShape(12.dp)){Text("Купить · ${fmt(spec.price.toDouble())} 🪙")} else {
                Row(verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text("Энергия ${owned.energy.roundToInt()}%",fontSize=11.sp);LinearProgressIndicator(progress={ (owned.energy/100).toFloat() },modifier=Modifier.fillMaxWidth().padding(top=3.dp),color=Purple);Text("Сытость ${owned.hunger.roundToInt()}%",fontSize=11.sp,modifier=Modifier.padding(top=5.dp));LinearProgressIndicator(progress={ (owned.hunger/100).toFloat() },modifier=Modifier.fillMaxWidth().padding(top=3.dp),color=Pink)};Spacer(Modifier.width(8.dp));Column {Text(if(owned.working)"Работает" else "Отдыхает",fontSize=10.sp,color=Muted);OutlinedButton(onClick={e.feed(owned.uid)},enabled=s.foodStock>0 && owned.hunger<100){Text("Покормить")};TextButton(onClick={e.releaseCat(owned.uid)}){Text("В приют",color=Muted)}}}
            }
        }}}}
    }
}

@Composable private fun ShopScreen(s:GameState,e:GameEngine){
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(10.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{SectionTitle("Усилители лапки","Текущая: ${Catalogs.buttons.first{it.id==s.buttonId}.name}")}
        items(Catalogs.buttons){b->val current=Catalogs.buttons.indexOfFirst{it.id==s.buttonId};val idx=Catalogs.buttons.indexOf(b); ShopCard(b.name,"×${b.multiplier} доход · до ${b.catCapacity} котов",b.rarity,b.price,s.coins,b.id==s.buttonId,idx<=current+1){e.buyButton(b.id)}}
        item{SectionTitle("Лежанки","Слотов отдыха: ${Catalogs.beds.first{it.id==s.bedId}.slots}")}
        items(Catalogs.beds){b->ShopCard(b.name,"${b.slots} мест · восстановление ${b.recovery}/сек",b.rarity,b.price,s.coins,b.id==s.bedId){e.buyBed(b.id)}}
        item{SectionTitle("Улучшения","Постоянные эффекты")}
        items(Catalogs.upgrades){u->ShopCard(u.second,when(u.first){"auto_feed"->"Автоматически кормит котов при низкой сытости";"quick_shift"->"Скорее возвращает котов к работе";"lucky_paw"->"Удача в кошачьей экономике";else->"+0.5 к силе каждого нажатия"},"Улучшение",u.third.toDouble(),s.coins,u.first in s.purchasedUpgrades){e.upgrade(u.first)}}
    }
}
@Composable private fun ShopCard(name:String,desc:String,rarity:String,price:Double,balance:Double,owned:Boolean,onBuy:()->Unit){Surface(color=Color.White,shape=RoundedCornerShape(17.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(name,fontWeight=FontWeight.Bold,color=Ink);Text(desc,fontSize=11.sp,color=Muted);Text(rarity.uppercase(),fontSize=9.sp,color=Purple,fontWeight=FontWeight.Bold,modifier=Modifier.padding(top=5.dp))};Button(onClick=onBuy,enabled=!owned&&balance>=price,shape=RoundedCornerShape(12.dp)){Text(if(owned)"Выбрано" else "${fmt(price)} 🪙",fontSize=11.sp)}}}}

@Composable private fun ProductionScreen(s:GameState,e:GameEngine){
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(11.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{SectionTitle("Кошачья кухня","Запас: ${s.foodStock} порций")}
        item{Surface(color=Color.White,shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(15.dp)){Text("Автокормушка",fontWeight=FontWeight.Bold,color=Ink);Text("Покупает еду из твоего запаса автоматически. Сначала пополни склад.",fontSize=11.sp,color=Muted);Row(verticalAlignment=Alignment.CenterVertically){Text(if(s.autoFeed)"Включена" else "Не куплена",fontSize=12.sp,color=Purple,modifier=Modifier.weight(1f));if(!s.autoFeed)Button(onClick={e.upgrade("auto_feed")},enabled=s.coins>=2500){Text("Купить · 2 500")}}}}}
        items(Catalogs.foods){f->Surface(color=Color.White,shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(f.icon,fontSize=30.sp);Spacer(Modifier.width(12.dp));Column(Modifier.weight(1f)){Text(f.name,fontWeight=FontWeight.Bold,color=Ink);Text("+${f.nutrition.roundToInt()} сытости",fontSize=11.sp,color=Muted)};Button(onClick={e.buyFood(f.id,3)},enabled=s.coins>=f.price*3){Text("3 шт. · ${f.price*3}")}}}}
        item{SectionTitle("Производство","Следующий этап развития")}
        item{Surface(color=Color(0xFFEFEAFF),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(15.dp)){Text("Ферма и рыбный цех",fontWeight=FontWeight.Bold,color=Ink);Text("Здания откроются в следующем крупном обновлении. Сейчас основной способ пополнить корм — магазин кухни.",fontSize=11.sp,color=Muted,modifier=Modifier.padding(top=5.dp))}}}
    }
}

@Composable private fun ProfileScreen(s:GameState,e:GameEngine){
    LazyColumn(Modifier.fillMaxSize(),verticalArrangement=Arrangement.spacedBy(12.dp),contentPadding=PaddingValues(bottom=18.dp)){
        item{SectionTitle("Профиль игрока","Уровень ${s.level}")}
        item{Surface(color=Color.White,shape=RoundedCornerShape(20.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text("Кошачий магнат",fontSize=20.sp,fontWeight=FontWeight.ExtraBold,color=Ink);Text("Престиж ${s.prestige} · ${s.crystals} кристаллов",color=Muted,fontSize=12.sp);Spacer(Modifier.height(14.dp));StatLine("Всего нажатий",s.taps.toString());StatLine("Всего заработано",fmt(s.totalCoins));StatLine("Котиков в команде",s.ownedCats.size.toString());StatLine("Достижения", "${s.unlockedAchievements.size}/4")}}}
        item{SectionTitle("Достижения","Награды за прогресс")}
        items(listOf("tap100" to "Первая сотня нажатий","tap1000" to "Тысяча лапок","cat3" to "Кошачья компания","rich" to "Первые 10 000 монет")){(id,title)->Surface(color=Color.White,shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Icon(if(id in s.unlockedAchievements)Icons.Default.EmojiEvents else Icons.Default.Lock,null,tint=if(id in s.unlockedAchievements)Pink else Muted);Spacer(Modifier.width(10.dp));Text(title,fontSize=13.sp,color=Ink);Spacer(Modifier.weight(1f));Text(if(id in s.unlockedAchievements)"Получено" else "Закрыто",fontSize=10.sp,color=Muted)}}}
        item{SectionTitle("Престиж","Сброс экономики ради бонуса")}
        item{Surface(color=Color(0xFFFFEAF0),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(15.dp)){Text("Новая кошачья эпоха",fontWeight=FontWeight.Bold,color=Ink);Text("При 100 000 заработанных монет можно начать заново и получить 1 кристалл престижа. Коты, монеты и магазин сбросятся.",fontSize=11.sp,color=Muted,modifier=Modifier.padding(vertical=8.dp));Button(onClick={e.prestige()},enabled=s.totalCoins>=100000){Text("Начать престиж · 100 000")}}}}
    }
}
@Composable private fun StatLine(label:String,value:String){Row(Modifier.fillMaxWidth().padding(vertical=5.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(label,fontSize=12.sp,color=Muted);Text(value,fontSize=12.sp,fontWeight=FontWeight.Bold,color=Ink)}}
private fun fmt(v:Double):String=when{v>=1_000_000_000->"%.2fB".format(v/1e9);v>=1_000_000->"%.2fM".format(v/1e6);v>=1000->"%.1fK".format(v/1000);else->v.roundToInt().toString()}
