# CAT CLICKER — Android project

Offline idle-clicker built with Kotlin, Jetpack Compose and a local SharedPreferences save store.

## Build

1. Install Android Studio (Ladybug or newer) with Android SDK Platform 35 and JDK 17.
2. Open this folder (`cat-clicker`) in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

Command line from a machine with Android SDK and Gradle installed:

```bash
gradle assembleDebug
```

## Included in this build

- Tap-to-earn paw button with press animation and critical reward every 37 taps.
- Cat catalog with eight original character entries, rarity, element, breed, description, price and income multiplier.
- Individual cat hunger and energy; timed work/rest loop.
- Beds with rest capacity and recovery rate.
- Food shop, manual feeding and unlockable auto-feeder.
- Paw button progression and cat capacity.
- Upgrades, basic breed combo, achievements, levels and prestige currency.
- Offline progress capped at eight hours.
- Local save/load; no internet permission or backend required.
- Responsive Compose layouts and original vector paw/cat-face artwork.

## Current release scope / known limitations

This is a playable first release foundation, not the full content scale in the concept brief. Production buildings, full elemental abilities/evolutions, skin inventory, rare-item collection, weekly/daily quest rotation, sound/music assets, cloud sync and advanced secret events are not implemented yet. The production tab currently provides food purchasing and auto-feed management. Cat artwork is vector-based rather than a set of hand-painted character illustrations. The game uses a soft hunger/productivity penalty and does not permanently kill cats; the release avoids irreversible pet-loss mechanics.

## Economy notes

- Manual tap starts at 1 coin and scales with player level and button multiplier.
- A critical tap occurs every 37 taps and grants 3×.
- Cat income depends on multiplier, button, energy and hunger.
- Cat work/rest cycles are timed; resting cats recover energy.
- Hunger gradually falls and lowers productivity below 50% / 20%.
- Prestige is available after 100,000 lifetime coins and grants one crystal.

## Project layout

- `engine/GameEngine.kt` — economy, cycles, purchases, achievements and offline progress.
- `engine/SaveManager.kt` — local JSON save persistence.
- `data/Catalogs.kt` — extensible catalogs for cats, beds, buttons, food and upgrades.
- `model/GameModels.kt` — game data models.
- `MainActivity.kt` — Compose navigation and screens.
